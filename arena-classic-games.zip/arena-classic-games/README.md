# Arena Classic Games — clean rebuild starter

A new, modular free-to-play game-platform prototype built after auditing the uploaded StakeClash, BetSquad v2, and BetSquad main archives. This project intentionally does **not** copy the old applications wholesale.

## Selected/rebuilt components

- **Whot engine:** rebuilt as a small pure module based on the useful Whot card/suit concepts from BetSquad main. Includes 75-card deck, 2- and 4-player setup, turn checks, legal move checks, WHOT suit declaration, draw flow and special-card effects.
- **Dice engine:** rebuilt as a pure four-round score engine based on the working Dice engine/test concepts in BetSquad main.
- **Snooker scoreboard:** rebuilt as a pure scoring practice module based on the existing score/foul model. This is not a physics-based table simulation.
- **Room validation:** new lightweight room rules for 1v1 and four-player formats, public/private room modes and private demo codes.
- **UI:** new responsive vanilla HTML/CSS/ES-module interface, with local practice bots for Whot and Dice.

## Important scope

This is a **local browser prototype**, not yet an online multiplayer service. Public matchmaking, accounts, cross-device rooms, real-time synchronization, admin tools and persistent rankings need a backend connection and integration tests. The room-code/private-room UI is demo-only. Leaderboard entries are sample display data. No wallet, deposits, stakes, payouts or real-money wagering are implemented.

## Run locally

Use a static web server (ES modules generally should not be opened directly as `file://`):

```bash
npm run serve
```

Or use any static server pointed at this directory.

## Run tests

```bash
npm test
```

The engine tests cover card count/uniqueness, legal and illegal Whot moves, suit declaration, turn handling, Dice scoring/ties/validation, Snooker scoring/fouls, and room rules.

## Next production milestones

1. Add an online backend (Supabase is an option) with one schema and strict row-level security.
2. Implement server-authoritative room membership, match state, reconnection, result validation and audit history.
3. Add integration tests with multiple authenticated clients and failure/reconnect cases.
4. Keep all money-related functions disabled until legal review, security review, age safeguards and compliant payment handling are complete.
