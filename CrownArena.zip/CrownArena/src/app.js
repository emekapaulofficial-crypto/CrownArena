import {SUITS, SUIT_GLYPHS, CARD_LABELS, createWhotState, currentPlayer as currentWhotPlayer, canPlay, playCard, drawCard} from './engines/whot.js';
import {createDiceState, rollForPlayer} from './engines/dice.js';
import {BALL_VALUES, createSnookerState, scoreBall, addFoul, finishSnooker} from './engines/snooker.js';
import {validateRoom, createRoomCode} from './engines/rooms.js';

const $ = (s) => document.querySelector(s);
const app = $('#app'), playArea = $('#playArea'), board = $('#gameBoard'), status = $('#matchStatus');
let active = null, botTimer = null, matchSerial = 0;
const botNames = ['Amaka','Tunde','Zara'];
const gameNames = {whot:'Nigerian Classic Whot',dice:'Dice Clash',snooker:'Snooker Scoreboard'};

function formatPlayers(format) { return format === '1v1' ? ['You','Amaka'] : ['You',...botNames]; }
function openPlayArea() { playArea.classList.remove('hidden'); playArea.scrollIntoView({behavior:'smooth',block:'start'}); }
function closeMatch() { if (botTimer) clearTimeout(botTimer); active=null; playArea.classList.add('hidden'); $('#games').scrollIntoView({behavior:'smooth'}); }
function showResult(title, message) { $('#resultTitle').textContent=title; $('#resultText').textContent=message; const d=$('#resultDialog'); if(!d.open)d.showModal(); }
function finish(title, message) { render(); showResult(title,message); }
function playerLabel(id) { return id==='you'?'You':id; }
function startMatch(game=$('#gameSelect').value, format=$('#formatSelect').value, visibility=$('#visibilitySelect').value) {
  if (game==='snooker') format='1v1';
  const names=formatPlayers(format), ids=names.map((_,i)=>i===0?'you':`bot${i}`);
  try { validateRoom({game,format,visibility,players:ids}); } catch (e) { status.textContent=e.message; return; }
  if (botTimer) clearTimeout(botTimer);
  matchSerial++;
  const common={game,format,visibility,names:Object.fromEntries(ids.map((id,i)=>[id,names[i]])),ids,serial:matchSerial,roomCode:visibility==='private'?createRoomCode():null};
  if(game==='whot') active={...common,type:'whot',state:createWhotState(ids)};
  if(game==='dice') active={...common,type:'dice',state:createDiceState(ids,4),lastRoll:null};
  if(game==='snooker') active={...common,type:'snooker',state:createSnookerState(ids)};
  $('#matchTitle').textContent=gameNames[game];
  status.textContent=`${format==='1v1'?'1v1 head-to-head':'4-player free-for-all'} · ${visibility==='public'?'Public matchmaking demo':'Private room demo'}${common.roomCode?` · Code ${common.roomCode}`:''}`;
  openPlayArea(); render(); maybeBotTurn();
}
function renderPlayers(ids, current, state) {
  return `<div class="players-strip">${ids.map(id=>`<div class="player-chip ${id===current?'active-player':''}"><b>${escapeHtml(active.names[id])}${id==='you'?' (you)':''}</b><small>${id===current?'● Current turn':state.status==='finished'?(state.winner===id?'🏆 Winner':'Match ended'):'Ready'}</small></div>`).join('')}</div>`;
}
function escapeHtml(value) { return String(value).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])); }
function cardText(card) { return card.value===20?'WHOT':`${card.value} ${SUIT_GLYPHS[card.suit]}`; }
function renderWhot() {
  const s=active.state, id=currentWhotPlayer(s), hand=s.hands.you||[], top=s.topCard;
  const canAct=id==='you'&&s.status==='active';
  const legal=hand.map((card,i)=>canPlay(card,top,s.declaredSuit)&&(!s.pendingPenalty||card.value===s.pendingPenaltyValue));
  board.innerHTML=`${renderPlayers(active.ids,id,s)}<div class="whot-table"><div><div class="hand-title">TABLE DISCARD · ${s.drawPile.length} cards left in draw pile</div><div style="color:#a2aec7;font-size:11px">${s.pendingPenalty?`Penalty active: draw ${s.pendingPenalty} or respond with ${s.pendingPenaltyValue}.`:'Match suit or number. WHOT can be played at any time.'}</div></div><div class="top-card">${escapeHtml(cardText(top))}<small>${escapeHtml(top.value===20?(s.declaredSuit||'choose suit'):top.suit)}</small></div></div><div class="hand-title">YOUR HAND · ${hand.length} CARDS</div><div class="hand">${hand.map((card,i)=>`<button class="playing-card ${legal[i]?'legal':''}" data-card="${i}" ${!canAct||!legal[i]?'disabled':''} aria-label="Play ${escapeHtml(cardText(card))}">${card.value}<span>${SUIT_GLYPHS[card.suit]}</span></button>`).join('')}</div><div class="board-actions"><button class="btn primary" id="drawCard" ${!canAct?'disabled':''}>${s.pendingPenalty?`Draw ${s.pendingPenalty} cards`:'Draw a card'}</button><button class="btn secondary" id="whotRules">How to play</button></div><p class="form-note">${escapeHtml(s.log.slice(-2).join(' '))}</p>`;
  board.querySelectorAll('[data-card]').forEach(btn=>btn.addEventListener('click',()=>{
    const index=Number(btn.dataset.card), card=active.state.hands.you[index]; let suit=null;
    if(card.value===20){const selected=prompt(`Choose a suit: ${SUITS.join(', ')}`,'circle'); if(!SUITS.includes((selected||'').toLowerCase()))return; suit=selected.toLowerCase();}
    try { playCard(active.state,'you',index,suit); render(); maybeBotTurn(); checkWhotFinished(); } catch(e) { status.textContent=e.message; }
  }));
  $('#drawCard').addEventListener('click',()=>{try{drawCard(active.state,'you');render();maybeBotTurn();checkWhotFinished();}catch(e){status.textContent=e.message;}});
  $('#whotRules').addEventListener('click',()=>showResult('Whot quick rules','Match the top card by suit or number. 1 gives you another turn; 2 means Pick Two; 5 means Pick Three; 8 skips the next player; 14 sends one card to every opponent; WHOT (20) lets you call a suit. This demo implements basic turn, draw and special-card effects.'));
}
function botWhotTurn() {
  const s=active?.state; if(!s||s.status!=='active')return;
  const id=currentWhotPlayer(s); if(id==='you')return;
  const hand=s.hands[id];
  let indexes=hand.map((c,i)=>({c,i})).filter(({c})=>canPlay(c,s.topCard,s.declaredSuit)&&(!s.pendingPenalty||c.value===s.pendingPenaltyValue));
  if(indexes.length){const pick=indexes[Math.floor(Math.random()*indexes.length)];playCard(s,id,pick.i,pick.c.value===20?SUITS[Math.floor(Math.random()*SUITS.length)]:null);}
  else drawCard(s,id);
  render(); checkWhotFinished();
  if(s.status==='active'&&currentWhotPlayer(s)!=='you') { botTimer=setTimeout(botWhotTurn,650); }
}
function checkWhotFinished(){const s=active?.state;if(s?.status==='finished')finish('🏆 '+active.names[s.winner]+' wins!',`${active.names[s.winner]} emptied their hand first. Start another free practice match whenever you are ready.`);}
function renderDice() {
  const s=active.state, current=s.ids?.[s.turnIndex] || s.playerIds[s.turnIndex], isYou=current==='you';
  board.innerHTML=`${renderPlayers(active.ids,current,s)}<div class="dice-score-grid">${active.ids.map(id=>`<div class="score-card"><span>${escapeHtml(active.names[id])}</span><strong>${s.totals[id]}</strong><small>${s.rolls.filter(r=>r.playerId===id).length} / ${s.rounds} rolls</small></div>`).join('')}</div><div class="roll-display">${active.lastRoll?`⚄ ${active.lastRoll.value}`:'⚄'}</div><div class="board-actions" style="justify-content:center"><button id="rollNow" class="btn primary" ${!isYou||s.status!=='playing'?'disabled':''}>${isYou?'Roll the die':'Waiting for opponent…'}</button></div><p class="form-note">Each player rolls once per round. The highest cumulative score after four rounds wins. Ties are shown clearly.</p>`;
  $('#rollNow').addEventListener('click',()=>{if(!active||active.type!=='dice')return;applyDiceTurn('you',Math.floor(Math.random()*6)+1);});
}
function applyDiceTurn(id,value){const s=active.state;try{active.lastRoll={player:id,value};const result=rollForPlayer(s,id,value);render();if(result.event==='winner'||result.event==='tie'){const winner=result.winners.map(pid=>active.names[pid]).join(' and ');finish(result.event==='tie'?'It’s a tie!':`${winner} wins!`,`Final scores: ${active.ids.map(pid=>`${active.names[pid]} ${s.totals[pid]}`).join(' · ')}.`);return;}maybeBotTurn();}catch(e){status.textContent=e.message;}}
function renderSnooker() {
  const s=active.state;
  board.innerHTML=`${renderPlayers(active.ids,s.currentPlayerId,s)}<div class="snooker-scores">${active.ids.map(id=>`<div class="snooker-player"><span>${escapeHtml(active.names[id])}</span><strong>${s.scores[id]}</strong><small>${id===s.currentPlayerId?'Your turn':'Waiting for turn'}</small></div>`).join('')}</div><div class="hand-title">POT A BALL · SCOREBOARD PRACTICE</div><div class="ball-buttons">${Object.entries(BALL_VALUES).map(([ball,points])=>`<button data-ball="${ball}" ${s.status!=='active'?'disabled':''}>${ball} +${points}</button>`).join('')}<button id="foul" ${s.status!=='active'?'disabled':''}>Foul (4)</button><button id="endFrame" class="btn primary">End frame</button></div><p class="form-note">This is a scorekeeping practice board, not a physics-based snooker simulation.</p>`;
  board.querySelectorAll('[data-ball]').forEach(btn=>btn.addEventListener('click',()=>{try{scoreBall(s,s.currentPlayerId,btn.dataset.ball);render();}catch(e){status.textContent=e.message;}}));
  $('#foul').addEventListener('click',()=>{try{addFoul(s,s.currentPlayerId,4);render();}catch(e){status.textContent=e.message;}});
  $('#endFrame').addEventListener('click',()=>{const r=finishSnooker(s);render();finish(r.tie?'Frame tied':`${active.names[r.winner]} wins the frame`,`${active.ids.map(id=>`${active.names[id]}: ${r.scores[id]}`).join(' · ')}`);});
}
function render(){if(!active)return;if(active.type==='whot')renderWhot();else if(active.type==='dice')renderDice();else renderSnooker();}
function maybeBotTurn(){if(!active)return;if(botTimer)clearTimeout(botTimer);if(active.type==='whot'){if(active.state.status==='active'&&currentWhotPlayer(active.state)!=='you')botTimer=setTimeout(botWhotTurn,600);}else if(active.type==='dice'){const s=active.state;const id=s.playerIds[s.turnIndex];if(s.status==='playing'&&id!=='you')botTimer=setTimeout(()=>applyDiceTurn(id,Math.floor(Math.random()*6)+1),650);}}

document.querySelectorAll('[data-game]').forEach(btn=>btn.addEventListener('click',()=>{const game=btn.dataset.game;$('#gameSelect').value=game;if(game==='snooker')$('#formatSelect').value='1v1';startMatch(game,$('#formatSelect').value,$('#visibilitySelect').value);}));
$('#matchForm').addEventListener('submit',e=>{e.preventDefault();startMatch();});
$('#quickMatch').addEventListener('click',()=>startMatch($('#gameSelect').value,$('#formatSelect').value,'public'));
$('#closeMatch').addEventListener('click',closeMatch);
$('#resultClose').addEventListener('click',()=>{$('#resultDialog').close();});
$('#formatSelect').addEventListener('change',()=>{if($('#gameSelect').value==='snooker'&&$('#formatSelect').value==='4-player')$('#gameSelect').value='whot';});
$('#gameSelect').addEventListener('change',()=>{if($('#gameSelect').value==='snooker')$('#formatSelect').value='1v1';});
$('#profileButton').addEventListener('click',()=>showResult('Player profile','Guest mode is active in this local preview. Sign-in, saved accounts and cross-device player profiles will be connected in the online backend phase.'));
