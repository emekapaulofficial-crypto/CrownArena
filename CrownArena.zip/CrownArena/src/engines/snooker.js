export const BALL_VALUES = Object.freeze({red:1,yellow:2,green:3,brown:4,blue:5,pink:6,black:7});
export function createSnookerState(playerIds = ['you','opponent']) {
  if (!Array.isArray(playerIds) || playerIds.length !== 2 || new Set(playerIds).size !== 2) throw new Error('Snooker requires two unique players');
  return {playerIds:[...playerIds], scores:Object.fromEntries(playerIds.map(id=>[id,0])), currentPlayerId:playerIds[0], status:'active', winner:null, history:[]};
}
export function scoreBall(state, playerId, ball) {
  if (state.status !== 'active') throw new Error('Match is not active');
  if (state.currentPlayerId !== playerId) throw new Error('Not this player\'s turn');
  if (!Object.hasOwn(BALL_VALUES, ball)) throw new Error('Invalid ball');
  state.scores[playerId] += BALL_VALUES[ball]; state.history.push({playerId, ball, points:BALL_VALUES[ball]});
  state.currentPlayerId = state.playerIds.find(id=>id !== playerId); return state;
}
export function addFoul(state, offenderId, points = 4) {
  if (state.status !== 'active') throw new Error('Match is not active');
  if (!state.playerIds.includes(offenderId) || !Number.isInteger(points) || points < 4 || points > 7) throw new Error('Invalid foul');
  const opponent = state.playerIds.find(id=>id !== offenderId); state.scores[opponent] += points;
  state.history.push({playerId:offenderId, foul:true, pointsAwarded:points, to:opponent}); state.currentPlayerId = opponent; return state;
}
export function finishSnooker(state) {
  state.status = 'finished'; const [a,b] = state.playerIds;
  state.winner = state.scores[a] === state.scores[b] ? null : (state.scores[a] > state.scores[b] ? a : b);
  return {winner:state.winner, tie:state.winner === null, scores:{...state.scores}};
}
