export function validateRoom({game, format, visibility = 'public', players = []}) {
  if (!['whot','dice','snooker'].includes(game)) throw new Error('Unsupported game');
  if (!['1v1','4-player'].includes(format)) throw new Error('Unsupported format');
  if (!['public','private'].includes(visibility)) throw new Error('Invalid room visibility');
  if (game === 'snooker' && format !== '1v1') throw new Error('Snooker currently supports 1v1 only');
  const capacity = format === '1v1' ? 2 : 4;
  if (!Array.isArray(players) || players.length > capacity || new Set(players).size !== players.length) throw new Error('Invalid room roster');
  return {game, format, visibility, capacity, players:[...players], status:players.length === capacity ? 'ready' : 'waiting'};
}
export function createRoomCode(random = Math.random) {
  const alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'; let code = '';
  for (let i=0;i<6;i++) code += alphabet[Math.floor(random()*alphabet.length)];
  return code;
}
