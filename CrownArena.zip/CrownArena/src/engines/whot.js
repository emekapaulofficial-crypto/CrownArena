export const SUITS = Object.freeze(['circle', 'triangle', 'cross', 'square', 'star']);
export const SUIT_GLYPHS = Object.freeze({circle:'●', triangle:'▲', cross:'✚', square:'■', star:'★'});
export const CARD_LABELS = Object.freeze({1:'Hold On',2:'Pick Two',5:'Pick Three',8:'Suspension',14:'General Market',20:'WHOT'});

export function createDeck() {
  const deck = [];
  for (const suit of SUITS) {
    for (let value = 1; value <= 14; value++) deck.push({ id:`${suit}-${value}`, suit, value });
    deck.push({ id:`${suit}-20`, suit, value:20 });
  }
  return deck;
}

export function shuffle(deck, random = Math.random) {
  const result = [...deck];
  for (let i = result.length - 1; i > 0; i--) {
    const j = Math.floor(random() * (i + 1));
    [result[i], result[j]] = [result[j], result[i]];
  }
  return result;
}

export function canPlay(card, topCard, declaredSuit = null) {
  if (!card || !topCard) return false;
  return card.value === 20 || card.suit === (declaredSuit || topCard.suit) || card.value === topCard.value;
}

export function createWhotState(playerIds, options = {}) {
  if (!Array.isArray(playerIds) || ![2,4].includes(playerIds.length) || new Set(playerIds).size !== playerIds.length) {
    throw new Error('Whot requires 2 or 4 unique players');
  }
  const random = options.random || Math.random;
  const deck = shuffle(createDeck(), random);
  const hands = Object.fromEntries(playerIds.map(id => [id, []]));
  for (let round = 0; round < 5; round++) for (const id of playerIds) hands[id].push(deck.pop());
  let topCard = deck.pop();
  while ([1,2,5,8,14,20].includes(topCard.value) && deck.length > 0) {
    deck.unshift(topCard);
    topCard = deck.pop();
  }
  return { playerIds:[...playerIds], hands, drawPile:deck, discardPile:[topCard], topCard, declaredSuit:null,
    turnIndex:0, status:'active', winner:null, pendingPenalty:0, pendingPenaltyValue:null,
    log:['Match started. Play a card matching the suit or number.'] };
}

export function currentPlayer(state) { return state.playerIds[state.turnIndex]; }
function advance(state, steps = 1) { state.turnIndex = (state.turnIndex + steps) % state.playerIds.length; }
function drawOne(state, playerId) {
  if (!state.drawPile.length && state.discardPile.length > 1) {
    const top = state.discardPile.pop();
    state.drawPile = shuffle(state.discardPile);
    state.discardPile = [top];
  }
  const card = state.drawPile.pop();
  if (card) state.hands[playerId].push(card);
  return Boolean(card);
}

export function drawCard(state, playerId) {
  if (state.status !== 'active') throw new Error('Match is not active');
  if (currentPlayer(state) !== playerId) throw new Error('Not this player\'s turn');
  const count = state.pendingPenalty || 1;
  for (let i = 0; i < count; i++) drawOne(state, playerId);
  state.log.push(`${playerId} drew ${count} card${count === 1 ? '' : 's'}.`);
  state.pendingPenalty = 0; state.pendingPenaltyValue = null; state.declaredSuit = null; advance(state);
  return state;
}

export function playCard(state, playerId, cardIndex, declaredSuit = null) {
  if (state.status !== 'active') throw new Error('Match is not active');
  if (currentPlayer(state) !== playerId) throw new Error('Not this player\'s turn');
  const hand = state.hands[playerId];
  if (!Number.isInteger(cardIndex) || !hand?.[cardIndex]) throw new Error('Invalid card');
  const card = hand[cardIndex];
  if (state.pendingPenalty && card.value !== state.pendingPenaltyValue) throw new Error('You must respond to the pending penalty or draw');
  if (!canPlay(card, state.topCard, state.declaredSuit)) throw new Error('Illegal move');
  if (card.value === 20 && !SUITS.includes(declaredSuit)) throw new Error('WHOT requires a declared suit');
  hand.splice(cardIndex, 1);
  state.discardPile.push(card); state.topCard = card;
  state.declaredSuit = card.value === 20 ? declaredSuit : null;
  state.log.push(`${playerId} played ${card.value === 20 ? 'WHOT' : `${card.value} ${card.suit}`}${card.value === 20 ? ` and called ${declaredSuit}` : ''}.`);

  if (hand.length === 0) {
    state.status = 'finished'; state.winner = playerId; state.log.push(`${playerId} wins!`); return { event:'winner', winner:playerId, state };
  }
  if (card.value === 2 || card.value === 5) {
    const penalty = card.value === 2 ? 2 : 3;
    state.pendingPenalty += penalty; state.pendingPenaltyValue = card.value; advance(state);
  } else if (card.value === 8) {
    advance(state, 2);
  } else if (card.value === 1) {
    // Hold On: the same player gets another turn.
  } else if (card.value === 14) {
    for (const other of state.playerIds) if (other !== playerId) drawOne(state, other);
    advance(state);
  } else {
    state.pendingPenalty = 0; state.pendingPenaltyValue = null; advance(state);
  }
  return { event:'played', nextPlayer:currentPlayer(state), state };
}
