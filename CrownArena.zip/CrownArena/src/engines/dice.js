export const DICE_ROUNDS = 4;
export function rollDie(random = Math.random) { return Math.min(6, Math.floor(random() * 6) + 1); }
export function createDiceState(playerIds, rounds = DICE_ROUNDS) {
  if (!Array.isArray(playerIds) || ![2,4].includes(playerIds.length) || new Set(playerIds).size !== playerIds.length) throw new Error('Dice requires 2 or 4 unique players');
  if (!Number.isInteger(rounds) || rounds < 1 || rounds > 20) throw new Error('Invalid rounds');
  return { playerIds:[...playerIds], rounds, round:1, turnIndex:0, totals:Object.fromEntries(playerIds.map(id=>[id,0])), rolls:[], status:'playing', winner:null, winners:[] };
}
export function rollForPlayer(state, playerId, value) {
  if (state.status !== 'playing') throw new Error('Game is finished');
  if (state.playerIds[state.turnIndex] !== playerId) throw new Error('Not this player\'s turn');
  if (!Number.isInteger(value) || value < 1 || value > 6) throw new Error('Die value must be from 1 to 6');
  state.totals[playerId] += value; state.rolls.push({playerId, round:state.round, value});
  if (state.turnIndex === state.playerIds.length - 1 && state.round === state.rounds) {
    const high = Math.max(...Object.values(state.totals)); state.winners = state.playerIds.filter(id=>state.totals[id] === high);
    state.winner = state.winners.length === 1 ? state.winners[0] : null; state.status = 'finished';
    return {event:state.winners.length > 1 ? 'tie' : 'winner', winners:[...state.winners], state};
  }
  if (state.turnIndex === state.playerIds.length - 1) state.round++;
  state.turnIndex = (state.turnIndex + 1) % state.playerIds.length;
  return {event:'roll', state};
}
