import test from 'node:test';
import assert from 'node:assert/strict';
import {SUITS, createDeck, createWhotState, canPlay, playCard, drawCard, currentPlayer} from '../src/engines/whot.js';
import {createDiceState, rollForPlayer} from '../src/engines/dice.js';
import {BALL_VALUES, createSnookerState, scoreBall, addFoul, finishSnooker} from '../src/engines/snooker.js';
import {validateRoom, createRoomCode} from '../src/engines/rooms.js';

function deterministicRandom() { let seed=1234567; return () => { seed=(seed*16807)%2147483647; return (seed-1)/2147483646; }; }

test('Whot deck has 75 unique cards and five WHOT cards',()=>{
 const deck=createDeck(); assert.equal(deck.length,75); assert.equal(new Set(deck.map(c=>c.id)).size,75);
 assert.equal(deck.filter(c=>c.value===20).length,5); assert.deepEqual(SUITS.length,5);
});
test('Whot matching permits same suit, same value, or WHOT',()=>{
 const top={suit:'circle',value:4}; assert.equal(canPlay({suit:'circle',value:9},top),true);
 assert.equal(canPlay({suit:'star',value:4},top),true); assert.equal(canPlay({suit:'star',value:20},top),true);
 assert.equal(canPlay({suit:'star',value:9},top),false);
});
test('Whot creates valid 1v1 and four-player hands without duplicate player IDs',()=>{
 for(const ids of [['a','b'],['a','b','c','d']]){const s=createWhotState(ids,{random:deterministicRandom()});assert.equal(s.status,'active');assert.ok(ids.every(id=>s.hands[id].length===5));assert.equal(s.drawPile.length+s.discardPile.length+ids.length*5,75);}
 assert.throws(()=>createWhotState(['a','a']));
});
test('Whot rejects illegal moves and advances after a legal card',()=>{
 const s=createWhotState(['a','b'],{random:deterministicRandom()});const p=currentPlayer(s);const hand=s.hands[p];
 const bad=hand.findIndex(c=>!canPlay(c,s.topCard)); if(bad>=0)assert.throws(()=>playCard(s,p,bad),/Illegal move/);
 const good=hand.findIndex(c=>canPlay(c,s.topCard)&&![1,2,5,8,14,20].includes(c.value)); if(good>=0){playCard(s,p,good);assert.equal(currentPlayer(s),'b');}
});
test('Whot requires a suit declaration for a WHOT card',()=>{
 const s=createWhotState(['a','b'],{random:deterministicRandom()});s.hands.a[0]={id:'test',suit:'star',value:20};s.turnIndex=0;
 assert.throws(()=>playCard(s,'a',0),/declared suit/);playCard(s,'a',0,'triangle');assert.equal(s.declaredSuit,'triangle');
});
test('Whot draw is turn-checked and advances the turn',()=>{const s=createWhotState(['a','b'],{random:deterministicRandom()});assert.throws(()=>drawCard(s,'b'),/turn/);drawCard(s,'a');assert.equal(currentPlayer(s),'b');});
test('Dice match has strict turn order, valid rolls and declares highest total winner',()=>{
 const s=createDiceState(['a','b'],1);rollForPlayer(s,'a',6);const r=rollForPlayer(s,'b',2);assert.equal(r.event,'winner');assert.equal(s.winner,'a');assert.equal(s.status,'finished');
 assert.throws(()=>rollForPlayer(s,'a',4),/finished/);
});
test('Dice rejects invalid values and ties are explicit',()=>{
 const s=createDiceState(['a','b'],1);assert.throws(()=>rollForPlayer(s,'a',0),/1 to 6/);rollForPlayer(s,'a',4);const r=rollForPlayer(s,'b',4);assert.equal(r.event,'tie');assert.deepEqual(r.winners,['a','b']);
});
test('Snooker scoreboard records legal pots and foul points, then declares winner',()=>{
 const s=createSnookerState(['a','b']);scoreBall(s,'a','red');assert.equal(s.scores.a,1);assert.throws(()=>scoreBall(s,'a','black'),/turn/);addFoul(s,'b',4);assert.equal(s.scores.a,5);scoreBall(s,'a','black');const result=finishSnooker(s);assert.equal(result.winner,'a');assert.equal(BALL_VALUES.black,7);
});
test('Snooker rejects invalid balls and foul values',()=>{const s=createSnookerState(['a','b']);assert.throws(()=>scoreBall(s,'a','pinkish'),/Invalid ball/);assert.throws(()=>addFoul(s,'a',2),/Invalid foul/);});
test('Room rules support public/private 1v1 and four-player formats',()=>{
 assert.equal(validateRoom({game:'whot',format:'1v1',players:['a']}).capacity,2);
 assert.equal(validateRoom({game:'dice',format:'4-player',visibility:'public',players:['a','b','c','d']}).status,'ready');
 assert.throws(()=>validateRoom({game:'snooker',format:'4-player'}),/1v1 only/);
 assert.throws(()=>validateRoom({game:'whot',format:'1v1',players:['a','a']}),/roster/);
});
test('Private room codes are six characters and omit ambiguous characters',()=>{const code=createRoomCode(()=>0.1);assert.equal(code.length,6);assert.match(code,/^[A-HJ-NP-Z2-9]{6}$/);});

test('Whot Hold On retains turn and Suspension skips the next player',()=>{
 const hold=createWhotState(['a','b','c','d'],{random:deterministicRandom()});hold.hands.a[0]={id:'hold',suit:hold.topCard.suit,value:1};hold.turnIndex=0;playCard(hold,'a',0);assert.equal(currentPlayer(hold),'a');
 const skip=createWhotState(['a','b','c','d'],{random:deterministicRandom()});skip.hands.a[0]={id:'skip',suit:skip.topCard.suit,value:8};skip.turnIndex=0;playCard(skip,'a',0);assert.equal(currentPlayer(skip),'c');
});
test('Whot Pick Two accumulates penalty and General Market gives opponents one card',()=>{
 const penalty=createWhotState(['a','b','c','d'],{random:deterministicRandom()});penalty.hands.a[0]={id:'pick2',suit:penalty.topCard.suit,value:2};penalty.turnIndex=0;playCard(penalty,'a',0);assert.equal(penalty.pendingPenalty,2);assert.equal(currentPlayer(penalty),'b');
 const market=createWhotState(['a','b','c','d'],{random:deterministicRandom()});market.hands.a[0]={id:'market',suit:market.topCard.suit,value:14};market.turnIndex=0;const before=Object.fromEntries(['a','b','c','d'].map(id=>[id,market.hands[id].length]));playCard(market,'a',0);assert.equal(market.hands.a.length,before.a-1);for(const id of ['b','c','d'])assert.equal(market.hands[id].length,before[id]+1);
});
test('Four-player Dice completes four rounds and ranks all players',()=>{
 const s=createDiceState(['a','b','c','d'],4);let result;
 for(let round=0;round<4;round++)for(const id of ['a','b','c','d'])result=rollForPlayer(s,id, id==='a'?6: id==='b'?4: id==='c'?3:2);
 assert.equal(s.status,'finished');assert.equal(s.winner,'a');assert.equal(s.rolls.length,16);assert.equal(result.event,'winner');
});
test('Whot engine can finish a complete four-player practice match without illegal state',()=>{
 const s=createWhotState(['a','b','c','d']);let steps=0;
 while(s.status==='active'&&steps<3000){const id=currentPlayer(s),hand=s.hands[id];const moves=hand.map((c,i)=>({c,i})).filter(({c})=>canPlay(c,s.topCard,s.declaredSuit)&&(!s.pendingPenalty||c.value===s.pendingPenaltyValue));if(moves.length){const move=moves[0];playCard(s,id,move.i,move.c.value===20?'circle':null);}else drawCard(s,id);steps++;}
 assert.equal(s.status,'finished');assert.ok(steps<3000);assert.ok(s.winner===null||s.playerIds.includes(s.winner));
});
